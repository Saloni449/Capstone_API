﻿using Core.Dtos;
using Core.Entities;
using Core.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eye_Clinic_Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly ITokenService _tokenService;
        private readonly IPatientServiceBL _patientServiceBL;
        private readonly IConfiguration _config;
        private string generatedToken = null;

        public AuthController(IConfiguration config, ITokenService tokenService, IPatientServiceBL patientServiceBL)
        {
            _config = config;
            _tokenService = tokenService;
            _patientServiceBL = patientServiceBL;
        }


        [AllowAnonymous]
        [Route("signin")]
        [HttpPost]
        public async Task<UserDTO> signin(User user)
        {
            if (string.IsNullOrEmpty(user.email) || string.IsNullOrEmpty(user.password))
            {
                return null;
            }
            //IActionResult response = Unauthorized();
            UserDTO validUser = await GetUser(user);

            if (validUser != null)
            {
                generatedToken = _tokenService.BuildToken(_config["Jwt:Key"].ToString(), _config["Jwt:Issuer"].ToString(), validUser);
                if (generatedToken != null)
                {
                    HttpContext.Session.SetString("Token", generatedToken);

                    Token t = new Token();
                    t.token = generatedToken;

                    validUser.Token = t.token;

                    return await Task.FromResult(validUser);
                }
                else
                {
                    Token t = new Token();
                    t.token = null;

                    return null;
                }
            }
            else
            {
                Token t = new Token();
                t.token = null;

                return null;
            }

        }

        private async Task<UserDTO> GetUser(User user)
        {
            // Write your code here to authenticate the user     
            return await _patientServiceBL.AuthenticateAsync(user.email,user.password);
        }


        [Authorize]
        [Route("uservalid")]
        [HttpGet]
        public async Task<bool> uservalid(int id, string password)
        {
            // Write your code here to authenticate the user     
            return await _patientServiceBL.userValidAsync(id, password);
        }

        [AllowAnonymous]
        [Route("userexists")]
        [HttpGet]
        public async Task<bool> userexists(string email)
        {
            // Write your code here to authenticate the user     
            return await _patientServiceBL.userExistsAsync(email);
        }

    }
}
