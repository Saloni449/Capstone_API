﻿using Core.Entities;
using Core.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Eye_Clinic_Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PatientController : ControllerBase
    {
        private readonly IPatientServiceBL _patientServiceBL;
        public PatientController(IPatientServiceBL patientServiceBL)
        {
            _patientServiceBL = patientServiceBL;
        }


        // GET: api/<PatientController>
        [Authorize]
        [HttpGet("{email}")]
        public async Task<Patient> Get(string email)
        {
            return await _patientServiceBL.getInfoAsync(email);
        }

        // POST api/<PatientController>
        [HttpPost]
        public async Task<int> Post([FromBody] Patient value)
        {
            return await _patientServiceBL.createAsync(value);
        }

        // PUT api/<PatientController>/a@g.com
        [Authorize]
        [HttpPut("{id}")]
        public async Task<int> Put(int id,[FromBody] Patient value)
        {
            return await _patientServiceBL.updateAsync(id,value);
        }

    }
}
