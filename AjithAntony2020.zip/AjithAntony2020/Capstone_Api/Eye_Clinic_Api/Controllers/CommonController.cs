﻿using Core.Entities;
using Core.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Eye_Clinic_Api.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class CommonController : ControllerBase
    {
        private readonly IEyeClinicServiceBL _eyeClinicServiceBL;
        public CommonController(IEyeClinicServiceBL eyeClinicServiceBL)
        {
            _eyeClinicServiceBL = eyeClinicServiceBL;
        }

        // GET: api/<CommonController>
        [HttpGet]
        public async Task<IEnumerable<Country>> countries()
        {
            return await _eyeClinicServiceBL.getCountriesAsync();
        }


        // GET: api/<CommonController>
        [HttpGet]
        public async Task<IEnumerable<Province>> provinces()
        {
            return await _eyeClinicServiceBL.getProvincesAsync();
        }

        // GET: api/<CommonController>
        [HttpGet]
        public async Task<IEnumerable<Gender>> genders()
        {
            return await _eyeClinicServiceBL.getGendersAsync();
        }

        // GET: api/<CommonController>
        [Authorize]
        [HttpGet]
        public async Task<IEnumerable<Service>> services()
        {
            return await _eyeClinicServiceBL.getServicesAsync();
        }



        // GET: api/<CommonController>
        [Authorize]
        [HttpGet]
        public async Task<IEnumerable<Staff>> staff()
        {
            return await _eyeClinicServiceBL.getStaffAsync();
        }


        // GET: api/<CommonController>
        [Authorize]
        [HttpGet]
        public async Task<IEnumerable<Designation>> designations()
        {
            return await _eyeClinicServiceBL.getDesignationsAsync();
        }

        // GET: api/<CommonController>
        [Authorize]
        [HttpGet]
        public async Task<IEnumerable<Specialization>> specializations()
        {
            return await _eyeClinicServiceBL.getSpecializationsAsync();
        }


        [HttpPost]
        [Authorize]
        public async Task<int> book([FromBody] Appointment value)
        {
            return await _eyeClinicServiceBL.bookAppointmentAsync(value);
        }


        [HttpGet]
        public async Task<Appointment> getAppointment(int patient_id)
        {
            return await _eyeClinicServiceBL.getAppointmentAsync(patient_id);
        }


        [HttpDelete]
        public async Task<int> deleteAppointment(int patient_id)
        {
            return await _eyeClinicServiceBL.deleteAppointmentAsync(patient_id);
        }

    }
}
