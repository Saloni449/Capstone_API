﻿using Core.Entities;
using Core.Services;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Implementation
{
    public class EyeClinicServiceDB : IEyeClinicServiceDB
    {
        private readonly IConfiguration _config;
        private readonly string _connstr;

        public EyeClinicServiceDB(IConfiguration config)
        {
            _config = config;
            _connstr = _config.GetConnectionString("DefaultConnection");
        }

        public async Task<IEnumerable<Country>> getCountriesAsync()
        {
            IList<Country> countries = new List<Country>();
            SqlConnection conn = new SqlConnection(_connstr);
            conn.Open();
            SqlCommand comm = new SqlCommand("SELECT * FROM [dbo].[Country]", conn);
            try
            {
                SqlDataReader reader = comm.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Country country = new Country();

                        country.ID = Convert.ToInt32(reader[0]);
                        country.name = reader[1].ToString();

                        countries.Add(country);
                    }
                }
                else
                {
                    countries = null;
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

            return await Task.FromResult<IEnumerable<Country>>(countries);
        
        }

        public async Task<IEnumerable<Designation>> getDesignationsAsync()
        {
            IList<Designation> designations = new List<Designation>();
            SqlConnection conn = new SqlConnection(_connstr);
            conn.Open();
            SqlCommand comm = new SqlCommand("SELECT * FROM [dbo].[Designation]", conn);
            try
            {
                SqlDataReader reader = comm.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Designation designation = new Designation();

                        designation.ID = Convert.ToInt32(reader[0]);
                        designation.code = reader[1].ToString();
                        designation.description = reader[2].ToString();

                        designations.Add(designation);
                    }
                }
                else
                {
                    designations = null;
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

            return await Task.FromResult<IEnumerable<Designation>>(designations);

        }

        public async Task<IEnumerable<Gender>> getGendersAsync()
        {
            IList<Gender> genders = new List<Gender>();
            SqlConnection conn = new SqlConnection(_connstr);
            conn.Open();
            SqlCommand comm = new SqlCommand("SELECT * FROM [dbo].[Gender]", conn);
            try
            {
                SqlDataReader reader = comm.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Gender gender = new Gender();

                        gender.ID = Convert.ToInt32(reader[0]);
                        gender.code = reader[1].ToString();
                        gender.description = reader[2].ToString();

                        genders.Add(gender);
                    }
                }
                else
                {
                    genders = null;
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

            return await Task.FromResult<IEnumerable<Gender>>(genders);

        }

        public async Task<IEnumerable<Province>> getProvincesAsync()
        {
            IList<Province> provinces = new List<Province>();
            SqlConnection conn = new SqlConnection(_connstr);
            conn.Open();
            SqlCommand comm = new SqlCommand("SELECT * FROM [dbo].[Province]", conn);
            try
            {
                SqlDataReader reader = comm.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Province province = new Province();

                        province.ID = Convert.ToInt32(reader[0]);
                        province.name = reader[1].ToString();

                        provinces.Add(province);
                    }
                }
                else
                {
                    provinces = null;
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

            return await Task.FromResult<IEnumerable<Province>>(provinces);

        }

        public async Task<IEnumerable<Service>> getServicesAsync()
        {
            IList<Service> services = new List<Service>();
            SqlConnection conn = new SqlConnection(_connstr);
            conn.Open();
            SqlCommand comm = new SqlCommand("SELECT * FROM [dbo].[Service]", conn);
            try
            {
                SqlDataReader reader = comm.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Service service = new Service();

                        service.ID = Convert.ToInt32(reader[0]);
                        service.name = reader[1].ToString();
                        service.charge = Convert.ToDecimal(reader[2]);

                        services.Add(service);
                    }
                }
                else
                {
                    services = null;
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

            return await Task.FromResult<IEnumerable<Service>>(services);

        }

        public async Task<IEnumerable<Specialization>> getSpecializationsAsync()
        {
            IList<Specialization> specializations = new List<Specialization>();
            SqlConnection conn = new SqlConnection(_connstr);
            conn.Open();
            SqlCommand comm = new SqlCommand("SELECT * FROM [dbo].[Specialization]", conn);
            try
            {
                SqlDataReader reader = comm.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Specialization specialization = new Specialization();

                        specialization.ID = Convert.ToInt32(reader[0]);
                        specialization.name = reader[1].ToString();

                        specializations.Add(specialization);
                    }
                }
                else
                {
                    specializations = null;
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

            return await Task.FromResult<IEnumerable<Specialization>>(specializations);

        }

        public async Task<IEnumerable<Staff>> getStaffAsync()
        {
            IList<Staff> staffs = new List<Staff>();
            SqlConnection conn = new SqlConnection(_connstr);
            conn.Open();
            SqlCommand comm = new SqlCommand("SELECT * FROM [dbo].[Staff]", conn);
            try
            {
                SqlDataReader reader = comm.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Staff staff = new Staff();
                        staff.ID = Convert.ToInt32(reader[0]);
                        staff.first_name = reader[1].ToString();
                        staff.last_name = reader[2].ToString();
                        staff.email = reader[3].ToString();
                        staff.phone = reader[4].ToString();
                        staff.designation_id = Convert.ToInt32(reader[5]);
                        staff.qualification = reader[6].ToString();
                        staff.gender_id = Convert.ToInt32(reader[7]);
                        staff.specialization_id = Convert.ToInt32(reader[8]);

                        staffs.Add(staff);
                    }
                }
                else
                {
                    staffs = null;
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

            return await Task.FromResult<IEnumerable<Staff>>(staffs);

        }


        public async Task<int> bookAppointmentAsync(Appointment obj)
        {
            SqlConnection conn = new SqlConnection(_connstr);
            conn.Open();

            SqlCommand comm = new SqlCommand("INSERT INTO [dbo].[Appointment]([patient_id],[staff_id],[schedule],[branch_id],[service_id]) VALUES(" + obj.patient_id + ", " + obj.staff_id + ", '" + obj.schedule.ToString("yyyy-MM-dd HH:mm:ss.fff") + "', " + obj.branch_id + ", " + obj.service_id + ")", conn);
            int rowsaffected;
            try
            {
                rowsaffected = await comm.ExecuteNonQueryAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }


            return await Task.FromResult<int>(rowsaffected);
        }




        public async Task<Appointment> getAppointmentAsync(int patient_Id)
        {
            Appointment appointment = null;
            SqlConnection conn = new SqlConnection(_connstr);
            conn.Open();
            SqlCommand comm = new SqlCommand("SELECT * FROM [dbo].[Appointment] WHERE patient_id = " + patient_Id + " AND schedule > '" + System.DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss.fff") + "'", conn);
            try
            {
                SqlDataReader reader = comm.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        appointment = new Appointment();
                        appointment.ID = Convert.ToInt32(reader[0]);
                        appointment.patient_id = Convert.ToInt32(reader[1]);
                        appointment.staff_id = Convert.ToInt32(reader[2]);
                        appointment.schedule = Convert.ToDateTime(reader[3]);
                        appointment.branch_id = Convert.ToInt32(reader[4]);
                        appointment.service_id = Convert.ToInt32(reader[5]);
                    }
                }
                else
                {
                    appointment = null;
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

            return await Task.FromResult<Appointment>(appointment);

        }



        public async Task<int> deleteAppointmentAsync(int patient_Id)
        {
            SqlConnection conn = new SqlConnection(_connstr);
            conn.Open();

            SqlCommand comm = new SqlCommand("DELETE FROM [dbo].[Appointment] WHERE patient_id = " + patient_Id + " AND schedule >= '" + System.DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss.fff") + "'", conn);
            int rowsaffected;
            try
            {
                rowsaffected = await comm.ExecuteNonQueryAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }


            return await Task.FromResult<int>(rowsaffected);
        }


    }
}
