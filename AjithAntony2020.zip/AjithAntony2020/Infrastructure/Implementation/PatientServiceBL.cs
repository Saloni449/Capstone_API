﻿using Core.Dtos;
using Core.Entities;
using Core.Services;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Implementation
{
    public class PatientServiceBL : IPatientServiceBL
    {

        private readonly IPatientServiceDB _patientServiceDB;

        public PatientServiceBL(IPatientServiceDB patientServiceDB)
        {
            _patientServiceDB = patientServiceDB;
        }

        public async Task<UserDTO> AuthenticateAsync(string email, string password)
        {
            return await _patientServiceDB.AuthenticateAsync(email, password);
        }

        public async Task<int> createAsync(Patient obj)
        {
            return await  _patientServiceDB.createAsync(obj);
        }

        public async Task<int> updateAsync(int id, Patient obj)
        {
            return await _patientServiceDB.updateAsync(id, obj);
        }

        public async Task<Patient> getInfoAsync(string email)
        {
         return await _patientServiceDB.getInfoAsync(email);
        }

        public async Task<Patient> getInfoAsync(int barcode)
        {
            throw new NotImplementedException();
        }


        public async Task<bool> userExistsAsync(string email)
        {
            return await _patientServiceDB.userExistsAsync(email);
        }

        public async Task<bool> userValidAsync(int id, string password)
        {
            return await _patientServiceDB.userValidAsync(id, password);

        }
    }
}
