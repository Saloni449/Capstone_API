﻿using Core.Dtos;
using Core.Entities;
using Core.Services;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Implementation
{
    public class PatientServiceDB : IPatientServiceDB
    {
        private readonly IConfiguration _config;
        private readonly string _connstr;
        public PatientServiceDB(IConfiguration config)
        {
            _config = config;
            _connstr = _config.GetConnectionString("DefaultConnection");
        }


        public async Task<int> createAsync(Patient obj)
        {
            SqlConnection conn = new SqlConnection(_connstr);
            conn.Open();

            SqlCommand comm = new SqlCommand("INSERT INTO [dbo].[Patient]([first_name],[last_name],[gender_id],[date_of_birth],[email],[phone],[alt_phone],[password],[address_line_1],[address_line_2],[city],[province_id],[country_id],[zip_code]) VALUES('" + obj.first_name + "', '" + obj.last_name + "', " + obj.gender_id + ", '" + obj.date_of_birth.ToString("yyyy-MM-dd HH:mm:ss.fff") + "', '" + obj.email + "', '" + obj.phone + "', '" + obj.alt_phone + "', '" + obj.passsword + "', '" + obj.address_line_1 + "', '" + obj.address_line_2 + "', '" + obj.city + "', " + obj.province_id + ", " + obj.country_id + ", '" + obj.zip_code + "')", conn);
            int rowsaffected;
            try
            {
                rowsaffected = await comm.ExecuteNonQueryAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }


            return await Task.FromResult<int>(rowsaffected);
        }



        public async Task<int> updateAsync(int id, Patient obj)
        {
            SqlConnection conn = new SqlConnection(_connstr);
            conn.Open();
            SqlCommand comm = new SqlCommand("UPDATE [dbo].[Patient] SET [first_name] = '" + obj.first_name + "',[last_name] = '" + obj.last_name + "',[gender_id] = " + obj.gender_id + ",[date_of_birth] = '" + obj.date_of_birth.ToString("yyyy-MM-dd HH:mm:ss.fff") + "',[email] = '" + obj.email + "',[phone] = '" + obj.phone + "',[alt_phone] = '" + obj.alt_phone + "',[password] = '" + obj.passsword + "' ,[address_line_1] = '" + obj.address_line_1 + "',[address_line_2] = '" + obj.address_line_2 + "',[city] = '" + obj.city + "',[province_id] = " + obj.province_id + ",[country_id] = " + obj.country_id + ",[zip_code] = '" + obj.zip_code + "' WHERE Patient.ID = " + id, conn);

            int rowsaffected;
            try
            {
                rowsaffected = await comm.ExecuteNonQueryAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

            return await Task.FromResult<int>(rowsaffected);
        }


        public async Task<Patient> getInfoAsync(string email)
        {
            Patient patient = null;
            SqlConnection conn = new SqlConnection(_connstr);
            conn.Open();
            SqlCommand comm = new SqlCommand("SELECT * FROM [dbo].[Patient] WHERE email = '" + email + "'", conn);  
            try  
            {  
                SqlDataReader reader = comm.ExecuteReader();  
                if (reader.Read())  
                {
                    patient = new Patient();
                    patient.ID = Convert.ToInt32(reader[0]);
                    patient.first_name = reader[1].ToString();
                    patient.last_name = reader[2].ToString();
                    patient.gender_id = Convert.ToInt32(reader[3]);
                    patient.date_of_birth = Convert.ToDateTime(reader[4]);
                    patient.email = reader[5].ToString();
                    patient.phone = reader[6].ToString();
                    patient.alt_phone = reader[7].ToString();
                    patient.passsword = reader[8].ToString();
                    patient.address_line_1 = reader[9].ToString();
                    patient.address_line_2 = reader[10].ToString();
                    patient.city = reader[11].ToString();
                    patient.province_id = Convert.ToInt32(reader[12]);
                    patient.country_id = Convert.ToInt32(reader[13]);
                    patient.zip_code = reader[14].ToString();
                }  
                else  
                {
                    return null;
                }
                reader.Close();  
            }  
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

            return await Task.FromResult<Patient>(patient);

        }

        public async Task<UserDTO> AuthenticateAsync(string email, string password)
        {
            UserDTO user = null;
            SqlConnection conn = new SqlConnection(_connstr);
            conn.Open();
            SqlCommand comm = new SqlCommand("SELECT * FROM [dbo].[Patient] WHERE email = '" + email + "' AND password = '" + password + "'", conn);
            try
            {
                SqlDataReader reader = comm.ExecuteReader();
                if (reader.Read())
                {
                    user = new UserDTO();
                    user.ID = Convert.ToInt32(reader[0]);
                    user.Email = reader[5].ToString();
                    user.Password = reader[8].ToString();
                    user.Role = "valid_user";
                }
                else
                {
                    user = null;
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

            return await Task.FromResult<UserDTO>(user);
        }


        public async Task<bool> userExistsAsync(string email)
        {
            bool exists = false;
            SqlConnection conn = new SqlConnection(_connstr);
            conn.Open();
            SqlCommand comm = new SqlCommand("SELECT * FROM [dbo].[Patient] WHERE email = '" + email + "'", conn);
            try
            {
                SqlDataReader reader = comm.ExecuteReader();
                if (reader.Read())
                {
                    exists = true;
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

            return await Task.FromResult(exists);
        }

        public async Task<bool> userValidAsync(int id, string password)
        {
            bool valid = false;
            SqlConnection conn = new SqlConnection(_connstr);
            conn.Open();
            SqlCommand comm = new SqlCommand("SELECT * FROM [dbo].[Patient] WHERE id = '" + id + "' AND password = '" + password + "'", conn);
            try
            {
                SqlDataReader reader = comm.ExecuteReader();
                if (reader.Read())
                {
                    valid = true;
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

            return await Task.FromResult(valid);
        }


    }
}
