﻿using Core.Entities;
using Core.Services;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Implementation
{
    public class EyeClinicServiceBL : IEyeClinicServiceBL
    {
        private readonly IEyeClinicServiceDB _eyeClinicServiceDB;

        public EyeClinicServiceBL(IEyeClinicServiceDB eyeClinicServiceDB)
        {
            _eyeClinicServiceDB = eyeClinicServiceDB;
        }

        public async Task<IEnumerable<Country>> getCountriesAsync()
        {
            return await _eyeClinicServiceDB.getCountriesAsync();
        }

        public async Task<IEnumerable<Designation>> getDesignationsAsync()
        {
            return await _eyeClinicServiceDB.getDesignationsAsync();
        }

        public async Task<IEnumerable<Gender>> getGendersAsync()
        {
            return await _eyeClinicServiceDB.getGendersAsync();
        }

        public async Task<IEnumerable<Province>> getProvincesAsync()
        {
            return await _eyeClinicServiceDB.getProvincesAsync();
        }

        public async Task<IEnumerable<Service>> getServicesAsync()
        {
            return await _eyeClinicServiceDB.getServicesAsync();
        }

        public async Task<IEnumerable<Specialization>> getSpecializationsAsync()
        {
            return await _eyeClinicServiceDB.getSpecializationsAsync();
        }

        public async Task<IEnumerable<Staff>> getStaffAsync()
        {
            return await _eyeClinicServiceDB.getStaffAsync();
        }


        public async Task<int> bookAppointmentAsync(Appointment obj)
        {
            return await _eyeClinicServiceDB.bookAppointmentAsync(obj);
        }

        public async Task<Appointment> getAppointmentAsync(int patient_Id)
        {        
          return await _eyeClinicServiceDB.getAppointmentAsync(patient_Id);            
        }


        public async Task<int> deleteAppointmentAsync(int patient_Id)
        {
            return await _eyeClinicServiceDB.deleteAppointmentAsync(patient_Id);
        }

    }
}
