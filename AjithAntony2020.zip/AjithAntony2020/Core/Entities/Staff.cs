﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Core.Entities
{
    public class Staff
    {
        public int ID { get; set; }

        public string first_name { get; set; }

        public string last_name { get; set; }

        public string email { get; set; }

        public string phone { get; set; }

        public int designation_id { get; set; }

        public string qualification { get; set; }

        public int gender_id { get; set; }

        public int? specialization_id { get; set; }

    }

}
