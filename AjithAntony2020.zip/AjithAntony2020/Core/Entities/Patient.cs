﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Core.Entities
{
    public class Patient
    {
        public int ID { get; set; }

        public string first_name { get; set; }

        public string last_name { get; set; }

        public int gender_id { get; set; }

        public DateTime date_of_birth { get; set; }

        public string email { get; set; }

        public string phone { get; set; }

        public string alt_phone { get; set; }

        public string address_line_1 { get; set; }

        public string address_line_2 { get; set; }

        public string city { get; set; }

        public int province_id { get; set; }

        public int country_id { get; set; }

        public string zip_code { get; set; }

        public string passsword { get; set; }


    }
}
