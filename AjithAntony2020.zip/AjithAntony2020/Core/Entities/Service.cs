﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Core.Entities
{
    public class Service
    {
        public int ID { get; set; }

        public string name { get; set; }

        public decimal? charge { get; set; }

    }
}
