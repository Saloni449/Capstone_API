﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Core.Entities
{
    public class Specialization
    {
        public int ID { get; set; }

        public string name { get; set; }

    }
}
