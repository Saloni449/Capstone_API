﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Core.Entities
{
    public class Appointment
    {
        public int ID { get; set; }

        public int patient_id { get; set; }

        public int staff_id { get; set; }

        public DateTime schedule { get; set; }

        public int branch_id { get; set; }

        public int service_id { get; set; }

    }

}
