﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Core.Entities
{
    public class Designation
    {
        public int ID { get; set; }

        public string code { get; set; }

        public string description { get; set; }

    }
}
