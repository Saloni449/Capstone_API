﻿using Core.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Core.Services
{
    public interface IEyeClinicServiceBL
    {

        Task<IEnumerable<Country>> getCountriesAsync();

        Task<IEnumerable<Province>> getProvincesAsync();

        Task<IEnumerable<Gender>> getGendersAsync();

        Task<IEnumerable<Service>> getServicesAsync();

        Task<IEnumerable<Staff>> getStaffAsync();

        Task<IEnumerable<Designation>> getDesignationsAsync();

        Task<IEnumerable<Specialization>> getSpecializationsAsync();

        Task<int> bookAppointmentAsync(Appointment obj);

        Task<Appointment> getAppointmentAsync(int patient_Id);

        Task<int> deleteAppointmentAsync(int patient_Id);
    }
}
