﻿using Core.Dtos;
using Core.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Core.Services
{
    public interface IPatientServiceDB
    {

        Task<int> createAsync(Patient obj);

        Task<int> updateAsync(int id, Patient obj);

        Task<Patient> getInfoAsync(string email);

        Task<UserDTO> AuthenticateAsync(string email, string password);

        Task<bool> userExistsAsync(string email);

        Task<bool> userValidAsync(int id, string password);


    }
}
