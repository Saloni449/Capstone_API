﻿using Core.Dtos;
using Core.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Core.Services
{
    public interface IPatientServiceBL
    {
        Task<UserDTO> AuthenticateAsync(string email, string password);

        Task<int> createAsync(Patient obj);

        Task<Patient> getInfoAsync(int barcode);

        Task<Patient> getInfoAsync(string email);

        Task<int> updateAsync(int id, Patient obj);

        Task<bool> userExistsAsync(string email);

        Task<bool> userValidAsync(int id, string password);


    }
}
